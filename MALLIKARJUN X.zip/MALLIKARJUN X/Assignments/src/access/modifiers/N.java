package access.modifiers;

public class N {

		private long a=1089L;
		public int b=33;
		double c=22.929;

		public void methodpublic() 
		{
			System.out.println("class N:methodpublic");
		}
		protected void methodprotected()
		{
			System.out.println("class N:methodprotected");
		}
		private void methodprivate()
		{
			System.out.println("class N: methodprivate");
		}
		void methoddefault()
		{
			System.out.println("class N:methoddefault\n");
		}
		

	}
		

