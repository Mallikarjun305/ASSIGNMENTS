package access.modifiers;

public class M {

		private int A=22;
		long B=222;
		protected float C=14.21f;
		public void methodpublic() 
		{
			System.out.println("class M:methodpublic");
		}
		protected void methodprotected()
		{
			System.out.println("class M:methodprotected");
		}
		private void methodprivate()
		{
			System.out.println("class M: methodprivate");
		}
		void methoddefault()
		{
			System.out.println("class M:methoddefault\n");
		}
	}



