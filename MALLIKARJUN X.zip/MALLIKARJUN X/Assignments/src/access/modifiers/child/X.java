package access.modifiers.child;

public class X {

	private int i=4;
	long j=1444;
	protected float f=10.2f;
	public char k='p';

}


