package access.modifiers.child;

import access.modifiers.M;
import access.modifiers.N;

	public class Y extends N{

		public static void main(String[] args) {
			
			new M().methodpublic();
			
			System.out.println("Variables of long : "+new X().j);
			System.out.println("Variables of float : "+new X().f);
			System.out.println("Variables of char :  "+new X().k);
			
		}


	}

