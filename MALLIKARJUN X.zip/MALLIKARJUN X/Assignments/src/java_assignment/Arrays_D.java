package java_assignment;

public class Arrays_D {
	
	public static void main(String[] args) {

		//single-dimensional array
		int A[]= {1,2,3,4,5};
		for(int i=0;i<5;i++) {
		System.out.println("Elements of array A: "+A[i]);
		}


		//multidimensional array
		int[][] B = {
		            {2,4,6,6,8}, 
		            {4,8,12} };
		      
		      System.out.println("\nLength of row 1: " + B[0].length);
		      }
		}

