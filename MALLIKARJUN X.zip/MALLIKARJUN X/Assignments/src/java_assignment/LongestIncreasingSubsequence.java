package java_assignment;

public class LongestIncreasingSubsequence {
	
		public LongestIncreasingSubsequence(int[] arr, int i, int n, int prev)
	    {
	        // Base case: nothing is remaining
	        if (i == n) {
	            return;
	        }
	 
	        LongestIncreasingSubsequence1(arr, i + 1, n, prev);
	 
	        if (arr[i] > prev) {
	        }
	 
	        // return the maximum of the above two choices
	        return;
	    }
	 
	    private static int LongestIncreasingSubsequence1(int[] arr, int i, int n, int prev) {
			// TODO Auto-generated method stub
			return 0;
		}

		public static void main(String[] args)
	    {
	        int[] arr = { 0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15 };
	 
	        System.out.print("The length of the Longest Increasing Subsequence is "
	                        + LongestIncreasingSubsequence1(arr, 0, arr.length, Integer.MIN_VALUE));
	    }
	}


